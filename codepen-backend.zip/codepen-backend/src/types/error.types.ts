export interface HttpErrorPayload {
  message?: string
  code: number
}
